//
//  ViewController.swift
//  json scorecard
//
//  Created by MACOS on 6/22/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    var finalArr : [String] = []
    var team1 : [Any] = []
    var result : [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
       let url = URL(string: "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20cricket.scorecard%20where%20match_id%3D11985&format=json&diagnostics=true&env=store%3A%2F%2F0TxIGQMQbObzvU4Apia0V0&callback=")
        do{
            let data = try Data(contentsOf: url!)
            
            do{
                let json = try JSONSerialization.jsonObject(with: data, options: [])as! [String : Any]
                let query = json["query"] as![String : Any]
                
                let results = query["results"]as! [String : Any]
                let score = results["Scorecard"]as! [String : Any]
                let series = score["series"]as![String : String]
                finalArr.append(series["series_id"]!)
                finalArr.append(series["series_name"]!)
                let place = score["place"] as! [String : String]
                finalArr.append(place["stadium"]!)
                finalArr.append(place["city"]!)
                finalArr.append(place["country"]!)
                finalArr.append(score["mn"] as! String)
                
                let team = score["teams"]as![[String : Any]]
                
                for item in team{
                    var temp : [String] = []
                    temp.append(item["fn"]as! String)
                    temp.append(item["sn"]as! String)
                    
                    let logo = item["logo"]as! [String : String]
                    temp.append(logo["std"]!)
                    
                    
                    let flag = item["flag"] as! [String : String]
                    temp.append(flag["std"]!)
                    team1.append(temp)
                }
                
                let rest = score["result"]as! [String : Any]
                result.append(rest["winner"]as! String)
                result.append(rest["r"]as! String)
                
                    }
         }
        catch{
        }
            
            catch{
            }
        
    
    
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 1{
            return 100
        } else
        
        {
            return 45
        }
        }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0{
            return "Series Name"
        }
        else if section == 1{
            return "Team Deatils"
        }
        else {
            return "Results"
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return finalArr.count
        }
        else if section == 1{
            return team1.count
        }
        else {
            return result.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0
        {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = finalArr[indexPath.row]
        return cell
    }
       else if indexPath.section == 1
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "custCell", for: indexPath)as! custCell
            
            let temp = team1[indexPath.row] as! [String]
            cell.lBl.text = temp[0]
            
            let url1 = URL(string: temp[1])
            
            
            do {
                let dt = try Data(contentsOf: url1!)
            
                cell.imgV1.image = UIImage(data: dt)
            }
            catch
            {
                }
            
            let url2 = URL(string: temp[2])
            do {
                let dt1 = try Data(contentsOf: url2!)
                
                cell.imgV2.image = UIImage(data : dt1)
            }
            catch {
            }
            return cell
            
            
            }
        
        else {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            
            cell.textLabel?.text = result[indexPath.row]
            return cell
            
        }
            }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

