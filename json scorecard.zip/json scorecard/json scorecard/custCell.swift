//
//  custCell.swift
//  json scorecard
//
//  Created by MACOS on 6/22/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class custCell: UITableViewCell {

    @IBOutlet weak var imgV1: UIImageView!
    @IBOutlet weak var imgV2: UIImageView!
    @IBOutlet weak var lBl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
